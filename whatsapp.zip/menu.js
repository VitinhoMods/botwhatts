module.exports.getMenuMessage = () => {
  return `
🌟 *Bem-vindo(a) ao Menu de Comandos!* 🌟

*Abaixo, você encontra a lista dos meus comandos disponíveis:*

🌟 *Comandos Básicos*
 ➦ /ping - Verifica a conexão com o servidor.
 ➦ /info - Exibe informações sobre o bot.

🖼️ *Comandos de Stickers*
 ➦ /sticker - Cria stickers a partir de mídias.
 ➦ /stext - Cria stickers com texto personalizado.

👮 *Comandos de Administração*
 ➦ /ban  - _Bane um usuário do grupo_.
 ➦ /marcar - _Menciona usuários específicos_.
 ➦ /regras - _Exibe as regras do grupo_.
 ➦ /welcome - _Configura a mensagem de boas-vindas_.

*Desenvolvido por OnwDev* 🔥
`;
};

