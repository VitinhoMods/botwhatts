const path = require("path");
const fs = require('fs');
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const readline = require("readline");
const pino = require("pino");
const { 
  banUser, 
  deleteMessage, 
  antiSpam, 
  mentionUsers, 
  clearChat, 
  randomMessages,
  antiLink
} = require("./groupManagement");
const { getMenuMessage } = require("./menu");
const { handleStickerCommands } = require("./sticker");
const { chiparCasal } = require("./chiparCasal");
const { sendDeveloperInfo } = require("./commands/developerInfo");

// Importando os módulos de boas-vindas e regras
const { 
  handleGroupParticipantJoin, 
  handleWelcomeCommand, 
  handleWelcomeMessageResponse 
} = require("./welcomeManager");
const {
  handleRulesCommand,
  handleRulesMessageResponse,
  getRulesForGroup,
  pendingRulesRequests,
} = require("./rulesManager");

const question = (string) => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(string, resolve));
};

// Lista para controlar solicitações pendentes de mensagens de boas-vindas
const pendingWelcomeRequests = [];

async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState(
    path.resolve(__dirname, "auth")
  );

  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    printQRInTerminal: false,
    version,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: ["Ubuntu", "Chrome", "1.0.0"],
    markOnlineOnConnect: true,
  });

  if (!sock.authState.creds.registered) {
    let phoneNumber = await question("Informe o número com código do país (ex: 5511999999999): ");
    phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

    if (!phoneNumber) throw new Error("Número inválido!");

    const code = await sock.requestPairingCode(phoneNumber);
    console.log(`\nCódigo de pareamento: ${code}\n`);
  }

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log("Conexão fechada. Reconectando...");
      if (shouldReconnect) connect();
    } else if (connection === "open") {
      console.log("✅ Conectado com sucesso!");

      // Exemplo de uso de mensagens aleatórias
      const messages = [
        "Lembrem-se das regras do grupo!",
        "Participem ativamente!",
        "Respeitem todos os membros!"
      ];
      randomMessages(sock, "seu-grupo-id@grupos.whatsapp.net", messages, 60); // A cada 60 minutos
    }
  });

  sock.ev.on("creds.update", saveCreds);

  // Listener para eventos de grupo (quando membros entram)
  sock.ev.on("group-participants.update", async (groupEvent) => {
    await handleGroupParticipantJoin(sock, groupEvent);
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const text = msg.message.conversation?.toLowerCase() || 
                 msg.message.extendedTextMessage?.text?.toLowerCase() || 
                 "";
    const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith("@g.us");
    const sender = msg.key.participant || jid;

    // Processamento de mensagens privadas para regras e boas-vindas
    if (!isGroup) {
      // Tenta processar a resposta para edição de regras
      const processedRules = await handleRulesMessageResponse(sock, msg);
      if (processedRules) return;

      // Tenta processar como resposta à solicitação de mensagem de boas-vindas
      const processedWelcome = await handleWelcomeMessageResponse(sock, msg, pendingWelcomeRequests);
      if (processedWelcome) return;
    }

    // Verifica anti-link (ANTES DE TUDO)
    if (isGroup) {
      try {
        const antiLinkResult = await antiLink(sock, msg);
        if (antiLinkResult?.actionTaken) return;
      } catch (error) {
        console.error("Erro no anti-link:", error);
      }
    }

    // Verifica anti-spam
    if (isGroup) {
      const spamResult = await antiSpam(sock, msg);
      if (spamResult.action === "banned") return;
    }

    // Comandos de sticker
    const stickerCommands = ['/sticker', '/s', '!sticker', '/stext', '/st', '!stickertext', '/shelp', '/stickerhelp', '!shelp'];
    if (stickerCommands.some(cmd => text.startsWith(cmd))) {
      await handleStickerCommands(sock, msg);
      return;
    }

    // Comandos de administração (apenas em grupos)
    if (isGroup) {
      // Comando para configurar mensagem de boas-vindas
      if (text === "/welcome" || text === "/setwelcome") {
        await handleWelcomeCommand(sock, msg);
        pendingWelcomeRequests.push({
          userJid: sender,
          groupJid: jid,
          timestamp: Date.now()
        });
        return;
      }

      // Comando para editar regras (apenas administradores)
      if (text === "/editrules") {
        await handleRulesCommand(sock, msg);
        return;
      }

      // Comando para exibir as regras no grupo
      if (text === "/regras" || text === "/getrules") {
        const rules = getRulesForGroup(jid);
        await sock.sendMessage(jid, { text: `Regras do grupo:\n\n${rules}` });
        return;
      }

      if (text.startsWith("/ban ")) {
        const userId = text.split(" ")[1];
        if (!userId) {
          await sock.sendMessage(jid, { text: "Por favor, informe o número do usuário. Ex: /ban 5511999999999" });
          return;
        }
        const formattedUserId = userId.replace(/\D/g, "") + "@s.whatsapp.net";
        const result = await banUser(sock, jid, [formattedUserId]);
        await sock.sendMessage(jid, { text: result.error || "Usuário banido com sucesso" });
      }

      // Removido o código da função fixar

      if (text.startsWith("/marcar")) {
        const users = text.split(" ").slice(1);
        if (users.length === 0) {
          await sock.sendMessage(jid, { text: "Por favor, informe os números dos usuários. Ex: /marcar 5511999999999 5511888888888" });
          return;
        }
        const result = await mentionUsers(sock, jid, users, "Marcando usuários:");
        if (result.error) await sock.sendMessage(jid, { text: result.error });
      }

         // Verifica comandos de enviar figurinhas aleatórias
    if (text.startsWith('/figurinha') || text === '/recarregar_figurinhas') {
      // Tenta processar como comando de figurinha
      let handled = await handleStickerSenderCommands(sock, msg);
      if (handled) return;

      // Se não foi processado como figurinha, tenta processar como comando de recarga
      handled = await handleReloadStickerCommand(sock, msg);
      if (handled) return;
    }

      if (text === "/limpar") {
        await sock.sendMessage(jid, { text: "Tem certeza que deseja limpar o chat? (sim/não)" });
        const confirmation = await new Promise((resolve) => {
          sock.ev.once("messages.upsert", ({ messages }) => {
            const response = messages[0].message.conversation?.toLowerCase();
            resolve(response === "sim");
          });
        });
        if (confirmation) {
          const result = await clearChat(sock, jid);
          await sock.sendMessage(jid, { text: result.error || "Chat limpo com sucesso" });
        } else {
          await sock.sendMessage(jid, { text: "Operação cancelada." });
        }
      }
    }

    // Comando para chipar casal
    if (text === "/chipar") {
      try {
        const groupMetadata = await sock.groupMetadata(jid);
        const participants = groupMetadata.participants.map(p => p.id);
        const mensagemCasal = chiparCasal(participants);
        await sock.sendMessage(jid, { text: mensagemCasal });
      } catch (error) {
        console.error("Erro ao chipar casal:", error);
        await sock.sendMessage(jid, { text: "Erro ao tentar chipar casal. Tente novamente." });
      }
      return;
    }

    // Comando para informações do desenvolvedor
if (text === '/dev' || text === '/sobre' || text === '/developer') {
  await sendDeveloperInfo(sock, jid);
  return;
}

    // Comandos originais
    if (text === "/menu" || text === "/help" || text === "/comandos") {
  const imagePath = path.resolve(__dirname, 'fotos', 'menu.jpg');

  if (fs.existsSync(imagePath)) {
    await sock.sendMessage(jid, {
      image: { url: imagePath },
      caption: getMenuMessage(),
      mentions: [msg.key.participant || msg.key.remoteJid]
    });
  } else {
    await sock.sendMessage(jid, { 
      text: getMenuMessage(),
      mentions: [msg.key.participant || msg.key.remoteJid]
    });
  }
}

    if (text === "/ping") {
      await sock.sendMessage(jid, { text: "🏓 Pong!" });
    }

    // Limpa solicitações antigas de boas-vindas (mais de 10 minutos)
    const now = Date.now();
    const timeoutMs = 10 * 60 * 1000; // 10 minutos
    const expiredRequestsIndex = pendingWelcomeRequests.findIndex(req => now - req.timestamp > timeoutMs);
    if (expiredRequestsIndex !== -1) {
      pendingWelcomeRequests.splice(0, expiredRequestsIndex + 1);
    }
  });
}

connect()
  .then(() => console.log("Bot pronto para uso!"))
  .catch((err) => console.error("Erro na conexão:", err));
