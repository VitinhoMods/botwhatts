// rulesManager.js
const fs = require("fs");
const path = require("path");

const rulesFile = path.resolve(__dirname, "groupRules.json");

// Carrega as regras existentes, se houver
let groupRules = {};
if (fs.existsSync(rulesFile)) {
  try {
    groupRules = JSON.parse(fs.readFileSync(rulesFile, "utf8"));
  } catch (error) {
    console.error("Erro ao ler arquivo de regras:", error);
  }
}

// Lista para controlar solicitações pendentes de edição de regras
const pendingRulesRequests = [];

/**
 * Inicia o processo de edição das regras.
 * Deve ser chamada quando o comando /editrules for recebido no grupo.
 * Apenas administradores podem editar as regras.
 */
async function handleRulesCommand(sock, msg) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;

  // Certifica-se que o comando vem de um grupo
  if (!jid.endsWith("@g.us")) return;

  // Verifica se o remetente é admin do grupo
  let groupMetadata;
  try {
    groupMetadata = await sock.groupMetadata(jid);
  } catch (error) {
    console.error("Erro ao obter metadados do grupo:", error);
    return;
  }
  const participant = groupMetadata.participants.find(p => p.id === sender);
  // Verifica se o participante tem a propriedade "admin" definida (algumas versões podem retornar "admin" ou "superadmin")
  if (!participant || (!participant.admin && participant.admin !== "admin" && participant.admin !== "superadmin")) {
    await sock.sendMessage(jid, { text: "Desculpe, apenas administradores podem editar as regras." });
    return;
  }

  // Envia mensagem privada ao admin para editar as regras
  await sock.sendMessage(sender, { 
    text: "Enviei uma mensagem no privado para você editar as regras do grupo. Por favor, responda com o novo texto das regras." 
  });

  // Adiciona a solicitação à lista de pendentes
  pendingRulesRequests.push({
    userJid: sender,
    groupJid: jid,
    timestamp: Date.now()
  });
}

/**
 * Processa a resposta privada do usuário com as novas regras.
 * Retorna true se a mensagem foi processada como resposta para edição de regras.
 */
async function handleRulesMessageResponse(sock, msg) {
  const sender = msg.key.remoteJid;
  const requestIndex = pendingRulesRequests.findIndex(req => req.userJid === sender);
  if (requestIndex === -1) return false;

  const request = pendingRulesRequests[requestIndex];
  const newRules = msg.message.conversation || msg.message.extendedTextMessage?.text;
  if (!newRules) return false;

  // Atualiza as regras do grupo específico
  groupRules[request.groupJid] = newRules;
  fs.writeFileSync(rulesFile, JSON.stringify(groupRules, null, 2));

  // Confirma a atualização para o usuário
  await sock.sendMessage(sender, { 
    text: "As regras do grupo foram atualizadas com sucesso!" 
  });

  pendingRulesRequests.splice(requestIndex, 1);
  return true;
}

/**
 * Retorna as regras definidas para um grupo específico.
 */
function getRulesForGroup(groupJid) {
  return groupRules[groupJid] || "Nenhuma regra definida para este grupo.";
}

module.exports = {
  handleRulesCommand,
  handleRulesMessageResponse,
  getRulesForGroup,
  pendingRulesRequests,
};